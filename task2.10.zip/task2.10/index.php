<!DOCTYPE html>
<html lang="es">

<head>
	<meta charset="utf-8">
	<title>Web Portal - Includes and requires</title>
	<link href="style.css" rel="stylesheet" type="text/css" media="screen" />
</head>

<body>

<!-- The include and require statements are identical, except upon failure:
require will produce a fatal error and stop the script
include will only produce a warning and the script will continue -->

	<div id="header" class="container">

		<?php
		include 'logo.php';
		?>

		<?php
		include 'menu.php';
		?>

	</div>

	<?php
	include 'pictures.php';
	?>

	<div id="page">
		<div id="bg1">
			<div id="bg2">
				<div id="bg3">

					<?php
					include 'content.php';
					?>

					<?php
					include 'sidebar.php';
					?>

				</div>
			</div>
		</div>
	</div>



</body>

</html>
<?php
require_once 'calculator.php';

$firstCalcule = new Calculator();
$firstCalcule->setNum1(6);
$firstCalcule->setNum2(5);

echo "First Calcule values:<br>";
echo "num1 = " . $firstCalcule->getNum1() . "<br>";
echo "num2 = " . $firstCalcule->getNum2() . "<br><br>";

$secondCalcule = new Calculator(4, 3);

echo "Second Calcule values:<br>";
echo $secondCalcule->toString() . "<br><br>";
echo "Multiplication result: " . $secondCalcule->multiply() . "<br>";
echo "Addition result: " . $secondCalcule->add() . "<br>";
?>

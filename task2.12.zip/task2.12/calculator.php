<?php
class Calculator {
    private $num1;
    private $num2;

    public function __construct($num1 = 0, $num2 = 0) {
        $this->num1 = $num1;
        $this->num2 = $num2;
    }

    // Getters and Setters
    public function getNum1() {
        return $this->num1;
    }

    public function getNum2() {
        return $this->num2;
    }

    public function setNum1($value) {
        $this->num1 = $value;
    }

    public function setNum2($value) {
        $this->num2 = $value;
    }

    // Functions
    public function multiply() {
        return $this->num1 * $this->num2;
    }

    public function add() {
        return $this->num1 + $this->num2;
    }

    // ToString
    public function toString() {
        return "num1: {$this->num1}, num2: {$this->num2}";
    }
}
?>

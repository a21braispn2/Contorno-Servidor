<?php
require_once 'alien.php';

$alien1 = new Alien("Pepe");
$alien2 = new Alien("Luis");
$alien3 = new Alien("Marcos");

echo "Total number of aliens created: " . Alien::getNumberOfAliens();
?>

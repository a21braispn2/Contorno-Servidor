<?php
class Alien {
    private $name;

    private static $numberOfAliens = 0;

    public function __construct($name) {
        $this->name = $name;
        self::$numberOfAliens++;
    }
    // Getters and Setters
    public function getName() {
        return $this->name;
    }

    // Functions
    public static function getNumberOfAliens() {
        return self::$numberOfAliens;
    }
}
?>

<?php
require_once 'exPropiaExcept.php';
class ExPropiaClass {
    public static function testNumber($number) {
        if ($number === 0) {
            throw new ExPropia();
        } else {
            echo "Number is valid: $number<br>";
        }
    }
}
?>

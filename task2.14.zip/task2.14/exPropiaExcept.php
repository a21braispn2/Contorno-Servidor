<?php
class ExPropia extends Exception
{
    public function __construct(string $message = "Number is zero", int $code = 0, ?Exception $previous = null)
    {
        parent::__construct($message, $code, $previous);
    }
}

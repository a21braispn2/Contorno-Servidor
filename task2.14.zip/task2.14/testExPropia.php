<?php
require_once 'exPropia.php';

$numbers = [0, 12, 0, 7, -1, 0, 99];

foreach ($numbers as $num) {
    try {
        ExPropiaClass::testNumber($num);
    } catch (ExPropia $e) {
        echo "Error: " . $e->getMessage() . "<br>";
    }
}
?>
